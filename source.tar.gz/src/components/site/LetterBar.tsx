import Link from 'next/link'
import React from 'react'

export function LetterBar({ have, current }: { have: Set<string>; current?: string }) {
  return (
    <nav className="letters" aria-label="Names by first letter">
      {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((l) =>
        have.has(l) ? (
          <Link key={l} href={`/name-coloring-pages/letter/${l.toLowerCase()}`} aria-current={current === l ? 'page' : undefined}>
            {l}
          </Link>
        ) : (
          <span key={l} aria-hidden="true">{l}</span>
        ),
      )}
    </nav>
  )
}
