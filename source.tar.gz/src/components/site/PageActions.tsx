'use client'

import dynamic from 'next/dynamic'
import React, { useEffect, useState } from 'react'
import { BrushIcon, DownloadIcon, PrintIcon } from './Icons'

// The coloring tool is only downloaded when someone opens it.
const ColoringStudio = dynamic(() => import('./ColoringStudio'), { ssr: false })

type Paper = 'letter' | 'a4'

export function PageActions({ slug, title, src, footer }: { slug: string; title: string; src: string; footer: string }) {
  const [paper, setPaper] = useState<Paper>('letter')
  const [studio, setStudio] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('paper')
    if (saved === 'a4' || saved === 'letter') setPaper(saved)
  }, [])

  const choose = (p: Paper) => {
    setPaper(p)
    try { localStorage.setItem('paper', p) } catch {}
  }

  return (
    <>
      <div className="actions">
        <a className="btn btn-print" href={`/print/${slug}?paper=${paper}&auto=1`} target="_blank" rel="nofollow noopener">
          <PrintIcon /> Print
        </a>
        <div className="row">
          <a className="btn" href={`/pdf/${slug}?paper=${paper}`} rel="nofollow" download>
            <DownloadIcon /> PDF
          </a>
          <button type="button" className="btn btn-color" onClick={() => setStudio(true)}>
            <BrushIcon /> Color online
          </button>
        </div>
        <div className="paper-size" role="group" aria-label="Paper size">
          <span>Paper:</span>
          <button type="button" aria-pressed={paper === 'letter'} onClick={() => choose('letter')}>US Letter</button>
          <button type="button" aria-pressed={paper === 'a4'} onClick={() => choose('a4')}>A4</button>
        </div>
      </div>
      {studio && <ColoringStudio src={src} title={title} footer={footer} fileName={slug} onClose={() => setStudio(false)} />}
    </>
  )
}
