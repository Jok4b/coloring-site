'use client'

import { useRouter } from 'next/navigation'
import React, { useEffect, useId, useRef, useState } from 'react'
import { SearchIcon } from './Icons'

type Result = { title: string; href: string; thumb: string | null; kind: 'page' | 'name' | 'category' }

export function SearchBox({ big = false, autoFocus = false, initial = '' }: { big?: boolean; autoFocus?: boolean; initial?: string }) {
  const router = useRouter()
  const [q, setQ] = useState(initial)
  const [results, setResults] = useState<Result[]>([])
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [active, setActive] = useState(-1)
  const boxRef = useRef<HTMLDivElement>(null)
  const listId = useId()

  useEffect(() => {
    const term = q.trim()
    if (term.length < 2) {
      setResults([])
      setLoading(false)
      return
    }
    setLoading(true)
    const ctrl = new AbortController()
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/search/suggest?q=${encodeURIComponent(term)}`, { signal: ctrl.signal })
        if (!res.ok) throw new Error(String(res.status))
        const data = (await res.json()) as { results: Result[] }
        setResults(data.results)
        setActive(-1)
      } catch (e) {
        if ((e as Error).name !== 'AbortError') setResults([])
      } finally {
        setLoading(false)
      }
    }, 200)
    return () => {
      clearTimeout(t)
      ctrl.abort()
    }
  }, [q])

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (!boxRef.current?.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (active >= 0 && results[active]) {
      router.push(results[active].href)
    } else if (q.trim()) {
      router.push(`/search?q=${encodeURIComponent(q.trim())}`)
    }
    setOpen(false)
  }

  const onKey = (e: React.KeyboardEvent) => {
    if (!open || !results.length) return
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActive((a) => (a + 1) % results.length)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActive((a) => (a <= 0 ? results.length - 1 : a - 1))
    } else if (e.key === 'Escape') {
      setOpen(false)
    }
  }

  const showPanel = open && q.trim().length >= 2 && !loading
  return (
    <div className={`search${big ? ' search-big' : ''}`} ref={boxRef}>
      <form role="search" onSubmit={submit}>
        <div className="search-field">
          <SearchIcon />
          <label htmlFor={`${listId}-input`} className="visually-hidden">Search coloring pages</label>
          <input
            id={`${listId}-input`}
            type="search"
            value={q}
            autoFocus={autoFocus}
            placeholder={big ? 'Try cat, unicorn, dinosaur…' : 'Search coloring pages'}
            autoComplete="off"
            enterKeyHint="search"
            role="combobox"
            aria-expanded={showPanel}
            aria-controls={listId}
            aria-autocomplete="list"
            aria-activedescendant={active >= 0 ? `${listId}-${active}` : undefined}
            onChange={(e) => {
              setQ(e.target.value)
              setOpen(true)
            }}
            onFocus={() => setOpen(true)}
            onKeyDown={onKey}
          />
          <button type="submit" className="search-go">Search</button>
        </div>
      </form>
      {showPanel && (
        <div className="search-panel" id={listId}>
          {results.length === 0 ? (
            <p className="search-empty">
              Nothing for “{q.trim()}” yet. Press Search to see similar pages.
            </p>
          ) : (
            <ul role="listbox" aria-label="Suggestions">
              {results.map((r, i) => (
                <li key={r.href}>
                  <a
                    id={`${listId}-${i}`}
                    role="option"
                    aria-selected={i === active}
                    href={r.href}
                    className="search-item"
                    onClick={(e) => {
                      e.preventDefault()
                      setOpen(false)
                      router.push(r.href)
                    }}
                  >
                    {r.thumb ? <img src={r.thumb} alt="" loading="lazy" /> : <span style={{ width: 44 }} />}
                    <span>{r.title}</span>
                    <span className="kind">{r.kind === 'name' ? 'Name page' : r.kind === 'category' ? 'Category' : ''}</span>
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
