import Link from 'next/link'
import React from 'react'

export function Pager({ page, total, base }: { page: number; total: number; base: string }) {
  if (total <= 1) return null
  return (
    <nav className="pager" aria-label="Pages">
      {page > 1 && <Link className="btn btn-small" href={page === 2 ? base : `${base}?page=${page - 1}`}>Previous</Link>}
      <span className="muted" style={{ alignSelf: 'center' }}>Page {page} of {total}</span>
      {page < total && <Link className="btn btn-small" href={`${base}?page=${page + 1}`}>Next</Link>}
    </nav>
  )
}
