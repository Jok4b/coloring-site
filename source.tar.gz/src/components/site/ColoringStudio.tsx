'use client'

import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { printImage } from './printImage'

/* Crayon box: rows of related colors so kids can find shades. */
const PALETTE = [
  '#e53935', '#ff7043', '#ff9800', '#ffc107', '#ffeb3b', '#fff59d',
  '#7cb342', '#43a047', '#1b5e20', '#26a69a', '#4dd0e1', '#81d4fa',
  '#1e88e5', '#3949ab', '#1a237e', '#8e24aa', '#ba68c8', '#e1bee7',
  '#ec407a', '#f48fb1', '#fce4ec', '#8d6e63', '#5d4037', '#d7a86e',
  '#ffccbc', '#f5d0b0', '#9e9e9e', '#616161', '#212121', '#ffffff',
]

const WHITE = 0xffffffff
const MAX_HISTORY = 40
type Step = { idx: Int32Array; prev: Uint32Array; next: number }
type Tool = 'fill' | 'erase'

const hexTo32 = (hex: string) => {
  const n = parseInt(hex.slice(1), 16)
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255
  return ((255 << 24) | (b << 16) | (g << 8) | r) >>> 0
}

type Props = { src: string; title: string; footer: string; fileName: string; onClose: () => void }

export default function ColoringStudio({ src, title, footer, fileName, onClose }: Props) {
  const stageRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const eng = useRef<{
    W: number; H: number; line: HTMLCanvasElement; barrier: Uint8Array
    fillData: ImageData; fill: Uint32Array; visited: Uint8Array; stack: Int32Array
  } | null>(null)
  const undoStack = useRef<Step[]>([])
  const redoStack = useRef<Step[]>([])

  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading')
  const [color, setColor] = useState(PALETTE[0])
  const [tool, setTool] = useState<Tool>('fill')
  const [zoom, setZoom] = useState(1)
  const [fit, setFit] = useState(1)
  const [, force] = useState(0)
  const landscape = eng.current ? eng.current.W > eng.current.H : false

  const render = useCallback(() => {
    const e = eng.current, c = canvasRef.current
    if (!e || !c) return
    const ctx = c.getContext('2d')!
    ctx.putImageData(e.fillData, 0, 0)
    ctx.globalCompositeOperation = 'multiply'
    ctx.drawImage(e.line, 0, 0)
    ctx.globalCompositeOperation = 'source-over'
  }, [])

  // Load the line art and prepare the fill engine.
  useEffect(() => {
    let cancelled = false
    const img = new Image()
    img.decoding = 'async'
    img.onload = () => {
      if (cancelled) return
      const nw = img.naturalWidth || 1700, nh = img.naturalHeight || 2200
      const long = Math.max(nw, nh)
      const target = Math.min(2200, Math.max(1400, long))
      const s = target / long
      const W = Math.round(nw * s), H = Math.round(nh * s)
      const line = document.createElement('canvas')
      line.width = W; line.height = H
      const lctx = line.getContext('2d', { willReadFrequently: true })!
      lctx.fillStyle = '#fff'
      lctx.fillRect(0, 0, W, H)
      lctx.drawImage(img, 0, 0, W, H)
      const px = lctx.getImageData(0, 0, W, H).data
      const barrier = new Uint8Array(W * H)
      for (let i = 0, p = 0; p < barrier.length; i += 4, p++) {
        // Dark and mid-grey pixels count as line, including the soft edges.
        barrier[p] = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2] < 185 ? 1 : 0
      }
      const fillData = new ImageData(W, H)
      const fill = new Uint32Array(fillData.data.buffer)
      fill.fill(WHITE)
      eng.current = { W, H, line, barrier, fillData, fill, visited: new Uint8Array(W * H), stack: new Int32Array(W * H) }
      const c = canvasRef.current!
      c.width = W; c.height = H
      render()
      setStatus('ready')
    }
    img.onerror = () => !cancelled && setStatus('error')
    img.src = src
    return () => { cancelled = true }
  }, [src, render])

  // Fit the sheet to the available space.
  useLayoutEffect(() => {
    const el = stageRef.current
    if (!el) return
    const measure = () => {
      const e = eng.current
      if (!e) return
      const pad = 24
      setFit(Math.min((el.clientWidth - pad) / e.W, (el.clientHeight - pad) / e.H))
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [status])

  const pushStep = (step: Step) => {
    undoStack.current.push(step)
    if (undoStack.current.length > MAX_HISTORY) undoStack.current.shift()
    redoStack.current = []
    force((n) => n + 1)
  }

  const fillAt = (x: number, y: number) => {
    const e = eng.current
    if (!e) return
    const { W, H, barrier, fill, visited, stack } = e
    let seed = y * W + x
    if (barrier[seed]) {
      // Tapped on a line: use the nearest open spot so thin areas are easy to hit.
      let best = -1
      for (let r = 1; r <= 10 && best < 0; r++) {
        for (let dy = -r; dy <= r && best < 0; dy++) {
          for (let dx = -r; dx <= r; dx++) {
            const nx = x + dx, ny = y + dy
            if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue
            const q = ny * W + nx
            if (!barrier[q]) { best = q; break }
          }
        }
      }
      if (best < 0) return
      seed = best
    }
    const color32 = tool === 'erase' ? WHITE : hexTo32(color)
    if (fill[seed] === color32) return

    visited.fill(0)
    const region: number[] = []
    let sp = 0
    stack[sp++] = seed
    visited[seed] = 1
    while (sp > 0) {
      const p = stack[--sp]
      region.push(p)
      const px = p % W
      if (px > 0) { const q = p - 1; if (!visited[q] && !barrier[q]) { visited[q] = 1; stack[sp++] = q } }
      if (px < W - 1) { const q = p + 1; if (!visited[q] && !barrier[q]) { visited[q] = 1; stack[sp++] = q } }
      if (p >= W) { const q = p - W; if (!visited[q] && !barrier[q]) { visited[q] = 1; stack[sp++] = q } }
      if (p < W * (H - 1)) { const q = p + W; if (!visited[q] && !barrier[q]) { visited[q] = 1; stack[sp++] = q } }
    }
    // Grow 3px under the line edges so no white halo shows next to the lines.
    let frontier = region
    for (let pass = 0; pass < 3; pass++) {
      const next: number[] = []
      for (const p of frontier) {
        const px = p % W
        const ns = [px > 0 ? p - 1 : -1, px < W - 1 ? p + 1 : -1, p >= W ? p - W : -1, p < W * (H - 1) ? p + W : -1]
        for (const q of ns) {
          if (q >= 0 && !visited[q] && barrier[q]) { visited[q] = 2; next.push(q) }
        }
      }
      for (const q of next) region.push(q)
      frontier = next
    }

    const idx = Int32Array.from(region)
    const prev = new Uint32Array(idx.length)
    for (let i = 0; i < idx.length; i++) { prev[i] = fill[idx[i]]; fill[idx[i]] = color32 }
    pushStep({ idx, prev, next: color32 })
    render()
  }

  const undo = useCallback(() => {
    const e = eng.current, step = undoStack.current.pop()
    if (!e || !step) return
    for (let i = 0; i < step.idx.length; i++) e.fill[step.idx[i]] = step.prev[i]
    redoStack.current.push(step)
    render(); force((n) => n + 1)
  }, [render])

  const redo = useCallback(() => {
    const e = eng.current, step = redoStack.current.pop()
    if (!e || !step) return
    for (let i = 0; i < step.idx.length; i++) e.fill[step.idx[i]] = step.next
    undoStack.current.push(step)
    render(); force((n) => n + 1)
  }, [render])

  const startOver = () => {
    const e = eng.current
    if (!e || !undoStack.current.length) return
    if (!window.confirm('Remove all your colors and start over?')) return
    e.fill.fill(WHITE)
    undoStack.current = []; redoStack.current = []
    render(); force((n) => n + 1)
  }

  const onCanvasClick = (ev: React.MouseEvent<HTMLCanvasElement>) => {
    const c = canvasRef.current, e = eng.current
    if (!c || !e) return
    const r = c.getBoundingClientRect()
    const x = Math.floor(((ev.clientX - r.left) / r.width) * e.W)
    const y = Math.floor(((ev.clientY - r.top) / r.height) * e.H)
    if (x >= 0 && y >= 0 && x < e.W && y < e.H) fillAt(x, y)
  }

  const finished = (withMark: boolean) => {
    const c = canvasRef.current!
    if (!withMark || !footer) return c
    const out = document.createElement('canvas')
    out.width = c.width; out.height = c.height
    const ctx = out.getContext('2d')!
    ctx.drawImage(c, 0, 0)
    ctx.font = `${Math.round(c.height * 0.014)}px sans-serif`
    ctx.fillStyle = '#9a9a9a'
    ctx.textAlign = 'right'
    ctx.fillText(footer, c.width - c.height * 0.02, c.height - c.height * 0.015)
    return out
  }

  const save = () => {
    finished(true).toBlob((blob) => {
      if (!blob) return
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `${fileName}-colored.png`
      a.click()
      setTimeout(() => URL.revokeObjectURL(a.href), 5000)
    }, 'image/png')
  }

  const print = () => printImage({ src: finished(false).toDataURL('image/png'), title, landscape, footer })

  // Keyboard shortcuts and page scroll lock.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault()
        if (e.shiftKey) redo(); else undo()
      }
    }
    window.addEventListener('keydown', onKey)
    const overflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = overflow }
  }, [onClose, undo, redo])

  const e = eng.current
  const cssW = e ? Math.round(e.W * fit * zoom) : 0
  const zooms = [1, 1.5, 2, 3, 4]
  const zi = zooms.indexOf(zoom)

  return (
    <div className="studio" role="dialog" aria-modal="true" aria-label={`Color ${title} online`}>
      <div className="studio-top">
        <button type="button" className="studio-icon" onClick={onClose} aria-label="Close">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" /></svg>
        </button>
        <strong className="studio-title">{title}</strong>
        <button type="button" className="studio-icon" onClick={undo} disabled={!undoStack.current.length} aria-label="Undo">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 14 4 9l5-5" /><path d="M4 9h10a6 6 0 0 1 0 12h-3" /></svg>
        </button>
        <button type="button" className="studio-icon" onClick={redo} disabled={!redoStack.current.length} aria-label="Redo">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 14 5-5-5-5" /><path d="M20 9H10a6 6 0 0 0 0 12h3" /></svg>
        </button>
      </div>

      <div className="studio-stage" ref={stageRef}>
        {status === 'loading' && <p className="studio-msg">Opening your page…</p>}
        {status === 'error' && <p className="studio-msg">This picture could not be opened. Close this window and try Print instead.</p>}
        <canvas
          ref={canvasRef}
          onClick={onCanvasClick}
          style={{ width: cssW || undefined, visibility: status === 'ready' ? 'visible' : 'hidden', cursor: tool === 'erase' ? 'cell' : 'pointer' }}
          aria-label="Tap an area to color it"
        />
      </div>

      <div className="studio-dock">
        <div className="studio-tools">
          <div className="seg" role="group" aria-label="Tool">
            <button type="button" aria-pressed={tool === 'fill'} onClick={() => setTool('fill')}>
              <span className="dot" style={{ background: color }} /> Color
            </button>
            <button type="button" aria-pressed={tool === 'erase'} onClick={() => setTool('erase')}>Eraser</button>
          </div>
          <div className="seg" role="group" aria-label="Zoom">
            <button type="button" onClick={() => setZoom(zooms[Math.max(0, zi - 1)])} disabled={zi <= 0} aria-label="Zoom out">−</button>
            <span className="zoom-val">{Math.round(zoom * 100)}%</span>
            <button type="button" onClick={() => setZoom(zooms[Math.min(zooms.length - 1, zi + 1)])} disabled={zi >= zooms.length - 1} aria-label="Zoom in">+</button>
          </div>
          <button type="button" className="studio-link" onClick={startOver} disabled={!undoStack.current.length}>Start over</button>
        </div>

        <div className="palette" role="radiogroup" aria-label="Colors">
          {PALETTE.map((c) => (
            <button
              key={c}
              type="button"
              role="radio"
              aria-checked={tool === 'fill' && color === c}
              aria-label={c}
              className="swatch"
              style={{ background: c }}
              onClick={() => { setColor(c); setTool('fill') }}
            />
          ))}
          <label className="swatch swatch-custom" title="Pick any color">
            <input type="color" value={color} onChange={(ev) => { setColor(ev.target.value); setTool('fill') }} aria-label="Pick any color" />
          </label>
        </div>

        <div className="studio-actions">
          <button type="button" className="btn btn-small" onClick={save} disabled={status !== 'ready'}>Save picture</button>
          <button type="button" className="btn btn-small btn-print" onClick={print} disabled={status !== 'ready'}>Print my picture</button>
        </div>
      </div>
    </div>
  )
}
