'use client'

import React, { useState } from 'react'

const CRAYONS = ['#ffc83d', '#3d8bff', '#2fb36b', '#ff5c8a', '#ff8a3d', '#9b6bff']

/** Headline drawn as outlined letters. Tapping a letter colors it in, like a coloring page. */
export function OutlineTitle({ text }: { text: string }) {
  const [fills, setFills] = useState<Record<number, string>>({})
  const [next, setNext] = useState(0)
  const color = (i: number) => {
    setFills((f) => ({ ...f, [i]: CRAYONS[next % CRAYONS.length] }))
    setNext((n) => n + 1)
  }
  const words = text.split(' ')
  let index = 0
  return (
    <h1 className="outline-title" aria-label={text}>
      {words.map((word, w) => (
        <React.Fragment key={w}>
          <span aria-hidden="true" style={{ whiteSpace: 'nowrap' }}>
            {Array.from(word).map((ch) => {
              const i = index++
              return (
                <span key={i} className="ch" style={fills[i] ? { color: fills[i] } : undefined} onClick={() => color(i)} onMouseEnter={(e) => e.buttons === 1 && color(i)}>
                  {ch}
                </span>
              )
            })}
          </span>
          {w < words.length - 1 ? ' ' : null}
        </React.Fragment>
      ))}
    </h1>
  )
}
