import Link from 'next/link'
import React from 'react'
import type { ColoringPage } from '@/payload-types'
import { mediaUrl, pageTitle } from '@/lib/site'

export function SheetCard({ page, priority = false }: { page: ColoringPage; priority?: boolean }) {
  const src = mediaUrl(page.image, 'thumb')
  const alt = (typeof page.image === 'object' && page.image?.alt) || pageTitle(page.title)
  return (
    <Link href={`/coloring-pages/${page.slug}`} className="sheet">
      <span className="sheet-paper">
        {src ? <img src={src} alt={alt} loading={priority ? 'eager' : 'lazy'} width={400} height={518} /> : null}
      </span>
      <span className="sheet-title">{page.title}</span>
    </Link>
  )
}

export function SheetGrid({ pages }: { pages: ColoringPage[] }) {
  return (
    <div className="sheet-grid">
      {pages.map((p, i) => (
        <SheetCard key={p.id} page={p} priority={i < 4} />
      ))}
    </div>
  )
}
