'use client'

import dynamic from 'next/dynamic'
import React, { useEffect, useRef, useState } from 'react'
import type { SheetTemplate } from '@/lib/queries'
import { printImage } from './printImage'
import { BrushIcon, DownloadIcon, PrintIcon } from './Icons'

const ColoringStudio = dynamic(() => import('./ColoringStudio'), { ssr: false })

/** Built-in design, always offered after your own name designs. */
const FRAME: SheetTemplate = {
  id: 'frame',
  title: 'Stars frame',
  src: null,
  width: 2200,
  height: 1700,
  box: { x: 50, y: 52, w: 78, h: 42 },
  upper: true,
}

function drawStar(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.beginPath()
  for (let i = 0; i < 10; i++) {
    const a = (Math.PI / 5) * i - Math.PI / 2
    const rr = i % 2 ? r * 0.45 : r
    ctx.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr)
  }
  ctx.closePath()
  ctx.stroke()
}

function drawFrame(ctx: CanvasRenderingContext2D, W: number, H: number) {
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 10
  ctx.lineJoin = 'round'
  const m = 70
  ctx.beginPath()
  ctx.roundRect(m, m, W - m * 2, H - m * 2, 60)
  ctx.stroke()
  ctx.lineWidth = 8
  const stars: [number, number, number][] = [
    [0.12, 0.16, 70], [0.3, 0.12, 45], [0.72, 0.13, 55], [0.88, 0.2, 80],
    [0.1, 0.82, 60], [0.26, 0.88, 40], [0.76, 0.87, 48], [0.9, 0.78, 66],
  ]
  for (const [x, y, r] of stars) drawStar(ctx, x * W, y * H, r)
}

const loadImage = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })

async function renderSheet(canvas: HTMLCanvasElement, t: SheetTemplate, name: string) {
  const img = t.src ? await loadImage(t.src) : null
  const W = img?.naturalWidth || t.width, H = img?.naturalHeight || t.height
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')!
  ctx.fillStyle = '#fff'
  ctx.fillRect(0, 0, W, H)
  if (img) ctx.drawImage(img, 0, 0, W, H)
  else drawFrame(ctx, W, H)

  const text = t.upper ? name.toUpperCase() : name
  const bw = (t.box.w / 100) * W, bh = (t.box.h / 100) * H
  const cx = (t.box.x / 100) * W, cy = (t.box.y / 100) * H
  await document.fonts.load('700 100px Fredoka').catch(() => undefined)
  let size = bh * 0.9
  const font = (s: number) => `700 ${s}px Fredoka, "Arial Rounded MT Bold", sans-serif`
  ctx.font = font(size)
  while (ctx.measureText(text).width > bw * 0.95 && size > 12) {
    size *= 0.94
    ctx.font = font(size)
  }
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.lineJoin = 'round'
  ctx.lineWidth = Math.max(4, size * 0.045)
  ctx.fillStyle = '#fff'
  ctx.strokeStyle = '#000'
  ctx.fillText(text, cx, cy)
  ctx.strokeText(text, cx, cy)
}

function Sheet({ t, name, footer, fileBase, onColor }: { t: SheetTemplate; name: string; footer: string; fileBase: string; onColor: (src: string, title: string) => void }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const [ready, setReady] = useState(false)
  const [failed, setFailed] = useState(false)
  const landscape = t.width > t.height

  useEffect(() => {
    setReady(false)
    setFailed(false)
    if (!ref.current || !name) return
    renderSheet(ref.current, t, name).then(() => setReady(true), () => setFailed(true))
  }, [t, name])

  const title = `${name} – ${t.title}`
  const data = () => ref.current!.toDataURL('image/png')
  const download = () => {
    const a = document.createElement('a')
    a.href = data()
    a.download = `${fileBase}-${t.id}.png`
    a.click()
  }

  return (
    <div className="name-sheet">
      <figure>
        <div className={`sheet-paper${landscape ? ' landscape' : ''}`}>
          <canvas ref={ref} role="img" aria-label={`${name} name coloring page, ${t.title} design`} />
        </div>
        <figcaption>{failed ? 'This design could not be loaded.' : t.title}</figcaption>
      </figure>
      <div className="btns">
        <button type="button" className="btn btn-small btn-print" disabled={!ready} onClick={() => printImage({ src: data(), title, landscape, footer })}>
          <PrintIcon /> Print
        </button>
        <button type="button" className="btn btn-small" disabled={!ready} onClick={() => onColor(data(), title)}>
          <BrushIcon /> Color online
        </button>
        <button type="button" className="btn btn-small" disabled={!ready} onClick={download} aria-label="Download picture">
          <DownloadIcon />
        </button>
      </div>
    </div>
  )
}

export function NameSheets({ name, templates, footer }: { name: string; templates: SheetTemplate[]; footer: string }) {
  const [studio, setStudio] = useState<{ src: string; title: string } | null>(null)
  const list = [...templates, FRAME]
  const fileBase = name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
  return (
    <>
      <div className="name-sheets">
        {list.map((t) => (
          <Sheet key={t.id} t={t} name={name} footer={footer} fileBase={fileBase} onColor={(src, title) => setStudio({ src, title })} />
        ))}
      </div>
      {studio && <ColoringStudio src={studio.src} title={studio.title} footer={footer} fileName={fileBase} onClose={() => setStudio(null)} />}
    </>
  )
}

/** "Type any name" box. Nothing is saved; the sheets are drawn in the browser. */
export function NameMaker({ templates, footer }: { templates: SheetTemplate[]; footer: string }) {
  const [value, setValue] = useState('')
  const [name, setName] = useState('')
  return (
    <section className="maker" aria-labelledby="maker-title">
      <h2 id="maker-title">Make a page with any name</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault()
          setName(value.trim().replace(/\s+/g, ' ').slice(0, 16))
        }}
      >
        <label htmlFor="maker-input" className="visually-hidden">Name</label>
        <input id="maker-input" value={value} onChange={(e) => setValue(e.target.value)} placeholder="Type a name" maxLength={16} autoComplete="off" />
        <button type="submit" className="btn btn-print" disabled={!value.trim()}>Make my pages</button>
      </form>
      {name ? <NameSheets name={name} templates={templates} footer={footer} /> : <p className="muted" style={{ margin: '12px 0 0' }}>Works for nicknames too, like Grandma or Coach Sam. Up to 16 letters.</p>}
    </section>
  )
}
