import React from 'react'

const base = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' } as const

export const PrintIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...base}>
    <path d="M6 9V3h12v6" />
    <rect x="3" y="9" width="18" height="8" rx="2" />
    <path d="M6 14h12v7H6z" />
  </svg>
)
export const DownloadIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...base}>
    <path d="M12 3v12" />
    <path d="m7 10 5 5 5-5" />
    <path d="M4 19h16" />
  </svg>
)
export const BrushIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...base}>
    <path d="M14 4l6 6-8.5 8.5a3 3 0 0 1-4.2 0l-1.8-1.8a3 3 0 0 1 0-4.2Z" />
    <path d="M4 20c1-1 1.5-2.5 1.2-3.8" />
  </svg>
)
export const SearchIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...base}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
)
/** Site mark: a crayon drawn in line art. */
export const CrayonMark = () => (
  <svg viewBox="0 0 40 40" aria-hidden="true">
    <g transform="rotate(-35 20 20)">
      <rect x="5" y="15" width="24" height="10" rx="2" fill="#ffc83d" stroke="#000" strokeWidth="2" />
      <path d="M29 15l7 5-7 5z" fill="#fff" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
      <path d="M11 15v10M23 15v10" stroke="#000" strokeWidth="2" />
    </g>
  </svg>
)
