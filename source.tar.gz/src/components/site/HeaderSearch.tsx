'use client'

import { usePathname } from 'next/navigation'
import React from 'react'
import { SearchBox } from './SearchBox'

/** Header search, hidden on pages that already show a big search box. */
export function HeaderSearch() {
  const path = usePathname()
  if (path === '/' || path === '/search') return null
  return (
    <div className="header-search">
      <SearchBox />
    </div>
  )
}
