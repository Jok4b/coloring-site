import Link from 'next/link'
import React from 'react'
import { CrayonMark } from './Icons'
import { HeaderSearch } from './HeaderSearch'

export function Header({ siteName }: { siteName: string }) {
  return (
    <header className="site-header">
      <div className="wrap">
        <Link href="/" className="logo">
          <CrayonMark />
          <span>{siteName}</span>
        </Link>
        <HeaderSearch />
        <nav className="nav" aria-label="Main">
          <Link href="/coloring-pages">All pages</Link>
          <Link href="/name-coloring-pages">Names</Link>
        </nav>
      </div>
    </header>
  )
}
