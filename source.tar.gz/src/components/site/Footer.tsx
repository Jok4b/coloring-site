import Link from 'next/link'
import React from 'react'

export function Footer({ siteName, text }: { siteName: string; text: string }) {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div>
          <strong>{siteName}</strong>
          <p className="muted" style={{ margin: '4px 0 0' }}>{text}</p>
        </div>
        <nav aria-label="Footer">
          <Link href="/coloring-pages">All coloring pages</Link>
          <Link href="/name-coloring-pages">Name coloring pages</Link>
        </nav>
      </div>
    </footer>
  )
}
