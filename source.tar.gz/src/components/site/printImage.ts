/** Opens a clean print dialog for one image, sized to a single sheet of paper. */
export function printImage(opts: { src: string; title: string; landscape: boolean; footer: string; paper?: 'letter' | 'a4' }) {
  const paper = opts.paper ?? (typeof localStorage !== 'undefined' && localStorage.getItem('paper') === 'a4' ? 'a4' : 'letter')
  const orient = opts.landscape ? 'landscape' : 'portrait'
  const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!)
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(opts.title)}</title>
<style>
@page { size: ${paper} ${orient}; margin: 0.4in; }
html,body { margin:0; height:100%; }
body { display:flex; flex-direction:column; align-items:center; justify-content:center; font:11px system-ui,sans-serif; color:#777; }
img { flex:1; min-height:0; max-width:100%; max-height:calc(100vh - 24px); object-fit:contain; }
p { margin:6px 0 0; }
</style></head><body><img src="${opts.src}" alt=""><p>${esc(opts.footer)}</p>
<script>
var img=document.images[0];
function go(){ setTimeout(function(){ window.focus(); window.print(); }, 150); }
if (img.complete) go(); else img.onload = go;
</script></body></html>`

  const win = window.open('', '_blank')
  if (win) {
    win.document.open()
    win.document.write(html)
    win.document.close()
    return
  }
  // Pop-ups blocked: print through a hidden frame instead.
  const frame = document.createElement('iframe')
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'
  document.body.appendChild(frame)
  const doc = frame.contentDocument!
  doc.open()
  doc.write(html.replace(/<script>[\s\S]*<\/script>/, ''))
  doc.close()
  const img = doc.images[0]
  const run = () => {
    frame.contentWindow?.focus()
    frame.contentWindow?.print()
    setTimeout(() => frame.remove(), 60_000)
  }
  if (img.complete) run()
  else img.onload = run
}
