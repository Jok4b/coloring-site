import type { Payload } from 'payload'
import React from 'react'

const box: React.CSSProperties = {
  border: '1px solid var(--theme-elevation-150)',
  borderRadius: 8,
  padding: '16px 20px',
  background: 'var(--theme-elevation-0)',
}

export async function Dashboard({ payload }: { payload: Payload }) {
  const [published, drafts, names, liveNames, templates, missed] = await Promise.all([
    payload.count({ collection: 'coloring-pages', where: { _status: { equals: 'published' } } }),
    payload.count({ collection: 'coloring-pages', where: { _status: { equals: 'draft' } } }),
    payload.count({ collection: 'names' }),
    payload.count({ collection: 'names', where: { published: { equals: true } } }),
    payload.count({ collection: 'name-templates', where: { active: { equals: true } } }),
    payload.find({ collection: 'search-logs', sort: '-count', limit: 6, depth: 0 }),
  ])

  const stats = [
    { label: 'Live coloring pages', value: published.totalDocs, href: '/admin/collections/coloring-pages?where[_status][equals]=published' },
    { label: 'Drafts', value: drafts.totalDocs, href: '/admin/collections/coloring-pages?where[_status][equals]=draft' },
    { label: 'Live name pages', value: `${liveNames.totalDocs} of ${names.totalDocs}`, href: '/admin/collections/names' },
    { label: 'Active name designs', value: templates.totalDocs, href: '/admin/collections/name-templates' },
  ]

  return (
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 16 }}>
        {stats.map((s) => (
          <a key={s.label} href={s.href} style={{ ...box, textDecoration: 'none', color: 'inherit' }}>
            <div style={{ fontSize: 28, fontWeight: 700 }}>{s.value}</div>
            <div style={{ opacity: 0.7 }}>{s.label}</div>
          </a>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 12 }}>
        <div style={box}>
          <h4 style={{ margin: '0 0 8px' }}>Most wanted pages you don’t have yet</h4>
          {missed.docs.length === 0 ? (
            <p style={{ margin: 0, opacity: 0.7 }}>No missed searches yet. They appear here when visitors search for something you don’t have.</p>
          ) : (
            <ol style={{ margin: 0, paddingLeft: 20 }}>
              {missed.docs.map((d) => (
                <li key={d.id}>
                  {d.query} <span style={{ opacity: 0.6 }}>({d.count}×)</span>
                </li>
              ))}
            </ol>
          )}
        </div>
        <div style={box}>
          <h4 style={{ margin: '0 0 8px' }}>Quick actions</h4>
          <p style={{ margin: '4px 0' }}><a href="/admin/collections/coloring-pages/create">Add a coloring page</a></p>
          <p style={{ margin: '4px 0' }}><a href="/admin/collections/categories/create">Add a category</a></p>
          <p style={{ margin: '4px 0' }}><a href="/admin/collections/name-imports/create">Import baby names</a></p>
          <p style={{ margin: '4px 0' }}><a href="/" target="_blank" rel="noreferrer">Open the website</a></p>
        </div>
      </div>
    </div>
  )
}
