import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import React from 'react'
import { getSettings } from '@/lib/payload'
import { pageBySlug } from '@/lib/queries'
import { mediaDims, mediaUrl, pageTitle, siteHost } from '@/lib/site'
import { AutoPrint, PrintButton } from './AutoPrint'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ paper?: string; auto?: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const page = await pageBySlug((await params).slug)
  return { title: page ? `Print: ${pageTitle(page.title)}` : 'Print', robots: { index: false, follow: false } }
}

export default async function PrintPage({ params, searchParams }: Props) {
  const { slug } = await params
  const sp = await searchParams
  const page = await pageBySlug(slug)
  if (!page) notFound()
  const s = await getSettings()
  const src = mediaUrl(page.image, 'original')!
  const { width, height } = mediaDims(page.image)
  const landscape = width > height
  const paper = sp.paper === 'a4' ? 'a4' : 'letter'
  const host = siteHost()
  const orient = landscape ? 'landscape' : 'portrait'
  // Usable height of one sheet after margins and the small footer line.
  const sheetH = paper === 'a4' ? (landscape ? '180mm' : '267mm') : landscape ? '7.2in' : '9.8in'

  return (
    <>
      <style>{`
        @page { size: ${paper} ${orient}; margin: 0.4in; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; background: #eceef3; color: #222; }
        .bar { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; padding: 12px 16px; background: #fff; border-bottom: 2px solid #000; position: sticky; top: 0; }
        .bar strong { flex: 1 1 200px; }
        .p-btn { min-height: 44px; padding: 0 18px; border: 2px solid #000; border-radius: 999px; background: #fff; font: 600 1rem system-ui; cursor: pointer; text-decoration: none; color: #000; display: inline-flex; align-items: center; }
        .p-main { background: #ffc83d; box-shadow: 0 3px 0 #000; }
        .p-on { background: #000; color: #fff; }
        .stage { padding: 24px 12px; display: flex; justify-content: center; }
        .print-sheet { background: #fff; width: min(100%, ${landscape ? '11in' : '8.5in'}); aspect-ratio: ${landscape ? '11 / 8.5' : '8.5 / 11'}; padding: 0.4in; display: flex; flex-direction: column; box-shadow: 0 2px 12px rgba(0,0,0,.15); }
        .print-sheet img { flex: 1; min-height: 0; width: 100%; object-fit: contain; }
        .print-sheet p { margin: 6px 0 0; text-align: center; font-size: 9px; color: #888; }
        @media print {
          body { background: #fff; }
          .bar { display: none; }
          .stage { padding: 0; }
          .print-sheet { width: 100%; height: ${sheetH}; aspect-ratio: auto; padding: 0; box-shadow: none; }
        }
      `}</style>
      <div className="bar">
        <strong>{pageTitle(page.title)}</strong>
        <Link className={`p-btn${paper === 'letter' ? ' p-on' : ''}`} href={`/print/${slug}?paper=letter`}>US Letter</Link>
        <Link className={`p-btn${paper === 'a4' ? ' p-on' : ''}`} href={`/print/${slug}?paper=a4`}>A4</Link>
        <PrintButton />
        <Link className="p-btn" href={`/coloring-pages/${slug}`}>Back</Link>
      </div>
      <div className="stage">
        <div className="print-sheet">
          <img src={src} alt={pageTitle(page.title)} />
          <p>{host ? `${s.siteName} · ${host}` : s.siteName} · Free to print for home and classroom use</p>
        </div>
      </div>
      <AutoPrint enabled={sp.auto === '1'} />
    </>
  )
}
