'use client'

import { useEffect } from 'react'

export function AutoPrint({ enabled }: { enabled: boolean }) {
  useEffect(() => {
    if (!enabled) return
    const img = document.querySelector<HTMLImageElement>('.print-sheet img')
    const go = () => setTimeout(() => window.print(), 200)
    if (!img || img.complete) go()
    else img.addEventListener('load', go, { once: true })
  }, [enabled])
  return null
}

export function PrintButton() {
  return (
    <button type="button" className="p-btn p-main" onClick={() => window.print()}>
      Print
    </button>
  )
}
