import React from 'react'

export const metadata = { robots: { index: false, follow: false } }

export default function PrintLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
