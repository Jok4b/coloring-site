import config from '@payload-config'
import { getPayload, type Payload } from 'payload'
import type { SiteSetting } from '@/payload-types'

export const getPayloadClient = (): Promise<Payload> => getPayload({ config })

/** True while `next build` runs. The database may not be reachable then. */
export const isBuildPhase = () => process.env.NEXT_PHASE === 'phase-production-build'

const DEFAULT_SETTINGS = {
  siteName: 'Coloring Pages',
  heroTitle: 'What do you want to color?',
  heroText: 'Free coloring pages you can print in one click, or color right here on your phone, tablet or computer.',
  homeDescription: 'Free printable coloring pages for kids and adults. Print in one click, download a PDF, or color online.',
  footerText: 'Free to print for home and classroom use.',
} as const

export type Settings = { [K in keyof typeof DEFAULT_SETTINGS]: string }

export async function getSettings(): Promise<Settings> {
  if (isBuildPhase()) return { ...DEFAULT_SETTINGS }
  try {
    const payload = await getPayloadClient()
    const s = (await payload.findGlobal({ slug: 'site-settings', depth: 0 })) as SiteSetting
    return {
      siteName: s.siteName || DEFAULT_SETTINGS.siteName,
      heroTitle: s.heroTitle || DEFAULT_SETTINGS.heroTitle,
      heroText: s.heroText || DEFAULT_SETTINGS.heroText,
      homeDescription: s.homeDescription || DEFAULT_SETTINGS.homeDescription,
      footerText: s.footerText || DEFAULT_SETTINGS.footerText,
    }
  } catch {
    return { ...DEFAULT_SETTINGS }
  }
}
