import path from 'path'

/** Folder where uploaded images and files are stored on the server. */
export const MEDIA_DIR = process.env.MEDIA_DIR || path.resolve(process.cwd(), 'media')
