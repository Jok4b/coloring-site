import type { Where } from 'payload'
import type { Category, ColoringPage, Name, NameTemplate } from '@/payload-types'
import { getPayloadClient } from './payload'

const PUBLISHED: Where = { _status: { equals: 'published' } }

export async function latestPages(limit = 12, page = 1) {
  const payload = await getPayloadClient()
  return payload.find({ collection: 'coloring-pages', where: PUBLISHED, sort: '-createdAt', limit, page, depth: 1 })
}

export async function pageBySlug(slug: string): Promise<ColoringPage | null> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'coloring-pages', where: { and: [PUBLISHED, { slug: { equals: slug } }] }, limit: 1, depth: 2 })
  return res.docs[0] ?? null
}

export async function relatedPages(page: ColoringPage, limit = 8) {
  const payload = await getPayloadClient()
  const catId = typeof page.category === 'object' ? page.category?.id : page.category
  const where: Where = { and: [PUBLISHED, { id: { not_equals: page.id } }, ...(catId ? [{ category: { equals: catId } }] : [])] }
  const res = await payload.find({ collection: 'coloring-pages', where, limit, depth: 1, sort: '-createdAt' })
  if (res.docs.length >= 4 || !catId) return res.docs
  const more = await payload.find({
    collection: 'coloring-pages',
    where: { and: [PUBLISHED, { id: { not_in: [page.id, ...res.docs.map((d) => d.id)] } }] },
    limit: limit - res.docs.length,
    depth: 1,
  })
  return [...res.docs, ...more.docs]
}

export async function allCategories(): Promise<Category[]> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'categories', limit: 200, sort: 'order', depth: 0 })
  return res.docs
}

export async function categoryBySlug(slug: string): Promise<Category | null> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'categories', where: { slug: { equals: slug } }, limit: 1, depth: 0 })
  return res.docs[0] ?? null
}

export async function pagesInCategory(id: number, limit = 48, page = 1) {
  const payload = await getPayloadClient()
  return payload.find({ collection: 'coloring-pages', where: { and: [PUBLISHED, { category: { equals: id } }] }, limit, page, depth: 1, sort: '-createdAt' })
}

export async function searchPages(q: string, limit = 48) {
  const payload = await getPayloadClient()
  const words = q.toLowerCase().split(/\s+/).filter((w) => w.length > 1 && !['coloring', 'page', 'pages', 'printable', 'free'].includes(w))
  const terms = words.length ? words : [q]
  const where: Where = {
    and: [
      PUBLISHED,
      { or: terms.flatMap((t): Where[] => [{ title: { like: t } }, { tags: { in: [t] } }, { description: { like: t } }]) },
    ],
  }
  return payload.find({ collection: 'coloring-pages', where, limit, depth: 1 })
}

export async function publishedNames(where: Where = {}, limit = 2000): Promise<Name[]> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'names', where: { and: [{ published: { equals: true } }, where] }, limit, depth: 0, sort: 'name', pagination: false })
  return res.docs
}

export async function nameBySlug(slug: string): Promise<Name | null> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'names', where: { and: [{ published: { equals: true } }, { slug: { equals: slug } }] }, limit: 1, depth: 0 })
  return res.docs[0] ?? null
}

export async function activeTemplates(): Promise<NameTemplate[]> {
  const payload = await getPayloadClient()
  const res = await payload.find({ collection: 'name-templates', where: { active: { equals: true } }, sort: 'order', limit: 12, depth: 1 })
  return res.docs
}

export async function logMissedSearch(query: string) {
  const q = query.trim().toLowerCase().replace(/\s+/g, ' ').slice(0, 60)
  if (q.length < 3 || /https?:|www\.|[<>{}]/.test(q)) return
  try {
    const payload = await getPayloadClient()
    const found = await payload.find({ collection: 'search-logs', where: { query: { equals: q } }, limit: 1, depth: 0, overrideAccess: true })
    const now = new Date().toISOString()
    if (found.docs[0]) {
      await payload.update({ collection: 'search-logs', id: found.docs[0].id, data: { count: (found.docs[0].count ?? 0) + 1, lastSearchedAt: now }, overrideAccess: true })
    } else {
      await payload.create({ collection: 'search-logs', data: { query: q, count: 1, lastSearchedAt: now }, overrideAccess: true })
    }
  } catch {
    // Logging must never break the search page.
  }
}

/** Template data the browser needs to draw a name sheet. */
export type SheetTemplate = {
  id: string
  title: string
  src: string | null
  width: number
  height: number
  box: { x: number; y: number; w: number; h: number }
  upper: boolean
}

export const toSheetTemplates = (docs: NameTemplate[]): SheetTemplate[] =>
  docs.map((t) => {
    const img = typeof t.image === 'object' ? t.image : null
    return {
      id: String(t.id),
      title: t.title,
      src: img?.url ?? null,
      width: img?.width ?? 1700,
      height: img?.height ?? 2200,
      box: { x: t.boxX, y: t.boxY, w: t.boxWidth, h: t.boxHeight },
      upper: t.letterCase !== 'normal',
    }
  })
