import type { Media } from '@/payload-types'

/** Public address of the site. Set SITE_URL on the server (no slash at the end). */
export const SITE_URL = (process.env.SITE_URL || 'http://localhost:3000').replace(/\/$/, '')

export const absoluteUrl = (p: string) => (/^https?:\/\//.test(p) ? p : `${SITE_URL}${p.startsWith('/') ? p : `/${p}`}`)

export const siteHost = () => {
  try {
    return new URL(SITE_URL).host
  } catch {
    return ''
  }
}

type Size = 'thumb' | 'card' | 'original'

/** URL of an uploaded image, in the requested size when it exists. */
export function mediaUrl(media: unknown, size: Size = 'original'): string | null {
  if (!media || typeof media !== 'object') return null
  const m = media as Media
  if (size !== 'original') {
    const s = m.sizes?.[size]
    if (s?.url) return s.url
  }
  return m.url ?? null
}

export const mediaDims = (media: unknown) => {
  const m = media as Media | null
  return { width: m?.width ?? 1700, height: m?.height ?? 2200 }
}

export const pageTitle = (title: string) =>
  /coloring (page|sheet)/i.test(title) ? title : `${title} coloring page`

export const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
