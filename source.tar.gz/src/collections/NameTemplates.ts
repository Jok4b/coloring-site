import type { CollectionConfig } from 'payload'

export const NameTemplates: CollectionConfig = {
  slug: 'name-templates',
  labels: { singular: 'Name design', plural: 'Name designs' },
  admin: {
    useAsTitle: 'title',
    group: 'Name pages',
    defaultColumns: ['title', 'active', 'order'],
    description:
      'Line-art designs with an empty space where the name is written. Box numbers are percentages of the image: X and Y are the center of the empty space.',
  },
  access: { read: () => true },
  defaultSort: 'order',
  fields: [
    { name: 'title', type: 'text', required: true, admin: { description: 'e.g. "Birthday balloons". Shown to visitors.' } },
    { name: 'image', type: 'upload', relationTo: 'media', required: true },
    {
      type: 'row',
      fields: [
        { name: 'boxX', label: 'Center X %', type: 'number', defaultValue: 50, min: 0, max: 100, required: true, admin: { width: '25%' } },
        { name: 'boxY', label: 'Center Y %', type: 'number', defaultValue: 50, min: 0, max: 100, required: true, admin: { width: '25%' } },
        { name: 'boxWidth', label: 'Width %', type: 'number', defaultValue: 80, min: 5, max: 100, required: true, admin: { width: '25%' } },
        { name: 'boxHeight', label: 'Height %', type: 'number', defaultValue: 25, min: 5, max: 100, required: true, admin: { width: '25%' } },
      ],
    },
    {
      type: 'row',
      fields: [
        {
          name: 'letterCase',
          type: 'select',
          defaultValue: 'upper',
          options: [
            { label: 'CAPITALS', value: 'upper' },
            { label: 'As typed (Emma)', value: 'normal' },
          ],
          admin: { width: '50%' },
        },
        { name: 'order', type: 'number', defaultValue: 10, admin: { width: '25%' } },
        { name: 'active', type: 'checkbox', defaultValue: true, admin: { width: '25%' } },
      ],
    },
  ],
}
