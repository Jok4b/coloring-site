import type { CollectionConfig } from 'payload'

export const SearchLogs: CollectionConfig = {
  slug: 'search-logs',
  labels: { singular: 'Missed search', plural: 'Missed searches' },
  admin: {
    useAsTitle: 'query',
    group: 'Insights',
    defaultColumns: ['query', 'count', 'lastSearchedAt'],
    description: 'Searches that found nothing. The most searched ones are the best ideas for your next coloring pages.',
  },
  access: {
    read: ({ req }) => Boolean(req.user),
    create: ({ req }) => Boolean(req.user),
    update: ({ req }) => Boolean(req.user),
    delete: ({ req }) => Boolean(req.user),
  },
  defaultSort: '-count',
  fields: [
    { name: 'query', label: 'Search', type: 'text', required: true, unique: true, index: true },
    { name: 'count', label: 'Times searched', type: 'number', defaultValue: 1 },
    { name: 'lastSearchedAt', label: 'Last searched', type: 'date', admin: { date: { pickerAppearance: 'dayAndTime' } } },
  ],
}
