import type { CollectionConfig } from 'payload'
import { MEDIA_DIR } from '../lib/paths'

export const Media: CollectionConfig = {
  slug: 'media',
  labels: { singular: 'Image', plural: 'Images' },
  admin: {
    group: 'Content',
    description: 'All uploaded images: coloring pages, name templates, category pictures.',
    defaultColumns: ['filename', 'alt', 'width', 'height', 'updatedAt'],
  },
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'alt',
      label: 'Image description',
      type: 'text',
      admin: { description: 'Short description for Google and screen readers, e.g. "Cat sitting on a pillow coloring page".' },
    },
  ],
  upload: {
    staticDir: MEDIA_DIR,
    mimeTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'],
    adminThumbnail: 'thumb',
    imageSizes: [
      { name: 'thumb', width: 400, formatOptions: { format: 'webp', options: { quality: 80 } } },
      { name: 'card', width: 800, formatOptions: { format: 'webp', options: { quality: 82 } } },
    ],
  },
}
