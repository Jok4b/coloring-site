import type { CollectionConfig } from 'payload'
import { slugField } from '../fields/slug'

export const Categories: CollectionConfig = {
  slug: 'categories',
  admin: {
    useAsTitle: 'name',
    group: 'Content',
    defaultColumns: ['name', 'slug', 'showOnHome', 'order'],
    description: 'Groups of coloring pages, like Animals or Holidays. Each gets its own page on the site.',
  },
  access: { read: () => true },
  defaultSort: 'order',
  fields: [
    { name: 'name', type: 'text', required: true, admin: { description: 'e.g. "Animals". The page title becomes "Animals coloring pages".' } },
    slugField('name'),
    {
      name: 'intro',
      type: 'textarea',
      admin: { description: 'Two or three sentences shown at the top of the category page. Written by you, helps SEO.' },
    },
    { name: 'order', type: 'number', defaultValue: 10, admin: { position: 'sidebar', description: 'Lower numbers show first.' } },
    { name: 'showOnHome', label: 'Show on home page', type: 'checkbox', defaultValue: true, admin: { position: 'sidebar' } },
  ],
}
