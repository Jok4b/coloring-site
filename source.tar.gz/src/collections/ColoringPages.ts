import type { CollectionConfig } from 'payload'
import { slugField } from '../fields/slug'

export const ColoringPages: CollectionConfig = {
  slug: 'coloring-pages',
  labels: { singular: 'Coloring page', plural: 'Coloring pages' },
  admin: {
    useAsTitle: 'title',
    group: 'Content',
    defaultColumns: ['title', 'category', 'difficulty', '_status', 'updatedAt'],
    listSearchableFields: ['title', 'slug'],
    description: 'Every printable page on the site. Use "Publish" to make one live; drafts stay hidden.',
    preview: (doc) => (doc?.slug ? `/coloring-pages/${doc.slug}` : null),
  },
  versions: { drafts: true },
  access: {
    read: ({ req }) => (req.user ? true : { _status: { equals: 'published' } }),
  },
  defaultSort: '-createdAt',
  fields: [
    { name: 'title', type: 'text', required: true, admin: { description: 'e.g. "Cat on a pillow". The site adds "coloring page" where it fits.' } },
    {
      name: 'image',
      label: 'Line art',
      type: 'upload',
      relationTo: 'media',
      required: true,
      admin: { description: 'Black lines on white or transparent background. PNG works best, at least 1600px tall.' },
    },
    {
      name: 'description',
      type: 'textarea',
      admin: { description: 'One or two sentences about this page. Shown on the page and used as the Google description.' },
    },
    {
      type: 'row',
      fields: [
        { name: 'category', type: 'relationship', relationTo: 'categories', admin: { width: '50%' } },
        {
          name: 'difficulty',
          type: 'select',
          defaultValue: 'easy',
          options: [
            { label: 'Easy (big shapes)', value: 'easy' },
            { label: 'Medium', value: 'medium' },
            { label: 'Detailed', value: 'detailed' },
          ],
          admin: { width: '25%' },
        },
        {
          name: 'audience',
          type: 'select',
          defaultValue: 'kids',
          options: [
            { label: 'Kids', value: 'kids' },
            { label: 'Adults', value: 'adults' },
            { label: 'Everyone', value: 'all' },
          ],
          admin: { width: '25%' },
        },
      ],
    },
    {
      name: 'tags',
      type: 'text',
      hasMany: true,
      admin: { description: 'Extra words people might search, e.g. kitten, pet, cute. Press Enter after each.' },
    },
    slugField('title'),
  ],
}
