import type { CollectionConfig } from 'payload'
import { slugField } from '../fields/slug'

export const Names: CollectionConfig = {
  slug: 'names',
  admin: {
    useAsTitle: 'name',
    group: 'Name pages',
    defaultColumns: ['name', 'gender', 'rank', 'year', 'published'],
    listSearchableFields: ['name'],
    description:
      'Each published name gets its own page at /name-coloring-pages/name. To publish many at once: tick them in the list, click "Edit", choose "Published" and save.',
  },
  access: {
    read: ({ req }) => (req.user ? true : { published: { equals: true } }),
  },
  defaultSort: 'rank',
  fields: [
    { name: 'name', type: 'text', required: true },
    slugField('name', 'Leave empty to create it from the name.'),
    {
      type: 'row',
      fields: [
        {
          name: 'gender',
          type: 'select',
          options: [
            { label: 'Girl', value: 'F' },
            { label: 'Boy', value: 'M' },
          ],
          admin: { width: '25%' },
        },
        { name: 'rank', type: 'number', admin: { width: '25%', description: 'Popularity rank in the US that year.' } },
        { name: 'births', type: 'number', admin: { width: '25%', description: 'Babies given this name that year.' } },
        { name: 'year', type: 'number', admin: { width: '25%' } },
      ],
    },
    {
      name: 'about',
      type: 'textarea',
      admin: { description: 'Optional. Anything true and useful about this name, written by you. Makes the page stronger for Google.' },
    },
    { name: 'published', type: 'checkbox', defaultValue: false, index: true, admin: { position: 'sidebar' } },
  ],
}
