import path from 'path'
import type { CollectionConfig } from 'payload'
import { toSlug } from '../fields/slug'
import { MEDIA_DIR } from '../lib/paths'

type Row = { name: string; gender: 'F' | 'M'; births: number; rank: number }

const parseSsaFile = (text: string, perGender: number): Row[] => {
  const byGender: Record<'F' | 'M', Row[]> = { F: [], M: [] }
  for (const line of text.split(/\r?\n/)) {
    const [name, sex, count] = line.trim().split(',')
    if (!name || (sex !== 'F' && sex !== 'M')) continue
    const births = Number(count)
    if (!Number.isFinite(births)) continue
    byGender[sex].push({ name: name.trim(), gender: sex, births, rank: 0 })
  }
  const out: Row[] = []
  for (const g of ['F', 'M'] as const) {
    byGender[g].sort((a, b) => b.births - a.births)
    byGender[g].slice(0, perGender).forEach((row, i) => out.push({ ...row, rank: i + 1 }))
  }
  return out
}

export const NameImports: CollectionConfig = {
  slug: 'name-imports',
  labels: { singular: 'Name import', plural: 'Name imports' },
  admin: {
    group: 'Name pages',
    useAsTitle: 'filename',
    defaultColumns: ['filename', 'year', 'perGender', 'summary', 'createdAt'],
    description:
      'Add many names at once from the official US baby names data. Download names.zip from ssa.gov (Social Security, "Beyond the Top 1000 Names"), open it, and upload one year file such as yob2024.txt. Names are added as unpublished so you can review them first.',
  },
  access: {
    read: ({ req }) => Boolean(req.user),
  },
  upload: {
    staticDir: path.join(MEDIA_DIR, 'imports'),
    mimeTypes: ['text/plain', 'text/csv', 'application/octet-stream'],
  },
  fields: [
    { name: 'year', type: 'number', required: true, admin: { description: 'The year of the file, e.g. 2024 for yob2024.txt.' } },
    {
      name: 'perGender',
      label: 'How many names per gender',
      type: 'number',
      defaultValue: 250,
      min: 1,
      max: 1000,
      required: true,
      admin: { description: '250 means the top 250 girl names and the top 250 boy names.' },
    },
    { name: 'summary', label: 'Result', type: 'textarea', admin: { readOnly: true } },
  ],
  hooks: {
    beforeChange: [
      async ({ data, req, operation }) => {
        if (operation !== 'create' || !req.file?.data) return data
        const rows = parseSsaFile(req.file.data.toString('utf8'), Number(data.perGender) || 250)
        if (!rows.length) {
          throw new Error('No names found. Upload a yobYYYY.txt file from the SSA names.zip (lines like "Olivia,F,14718").')
        }
        let created = 0
        let updated = 0
        let skipped = 0
        for (const row of rows) {
          const slug = toSlug(row.name)
          const existing = await req.payload.find({
            collection: 'names',
            where: { slug: { equals: slug } },
            limit: 1,
            req,
            overrideAccess: true,
          })
          const values = { name: row.name, gender: row.gender, rank: row.rank, births: row.births, year: Number(data.year) }
          const current = existing.docs[0]
          if (!current) {
            await req.payload.create({ collection: 'names', data: { ...values, slug, published: false }, req, overrideAccess: true })
            created++
          } else if (current.gender === row.gender || !current.rank || row.rank < current.rank) {
            await req.payload.update({ collection: 'names', id: current.id, data: values, req, overrideAccess: true })
            updated++
          } else {
            skipped++ // same name already stored with a better rank for the other gender
          }
        }
        data.summary = `Added ${created} new names, updated ${updated}, skipped ${skipped}. New names are unpublished.`
        return data
      },
    ],
  },
}
